package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Customer;
import com.capg.bean.OrderedItem;
import com.capg.bean.WishItem;
import com.capg.dao.CapgWishItemRepo;
import com.capg.dao.CapgCustomerRepo;
import com.capg.dao.CapgOrderedItem;

@Service
public class CapgService {
	
	@Autowired CapgCustomerRepo customerRepo;
	@Autowired CapgWishItemRepo customerWishRepo;
	@Autowired CapgOrderedItem repository;
	public void registerCustomer(Customer customer) {
		customerRepo.save(customer);
	}
	
	public Customer findCustomerById(String custId) {  
		return customerRepo.findById(custId).get();
	}
	public void updateCustomer(String custId, Customer customer) {
		customerRepo.save(customer);
	}
	public void addCustomerWish(String custId,WishItem wish) {
		Customer customer = findCustomerById(custId);
		List<WishItem> wishList = customer.getWishItems();
		wishList.add(wish);
		customer.setWishItems(wishList);
		customerWishRepo.save(wish);
		customerRepo.save(customer);
	}
	public List<OrderedItem> getOrderedItemsByCustId() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}	
	
	
	
	}


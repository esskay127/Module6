package com.capg.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Customer;
import com.capg.bean.Merchant;
import com.capg.bean.OrderedItem;
import com.capg.bean.WishItem;
//import com.capg.service.CapgService;
import com.capg.service.CapgService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CapgController {

	@Autowired CapgService capgService;
	


	@RequestMapping(value="/ecommerce/186133/deposit/{custId}/{amount}",method =RequestMethod.PUT)
	public void depositAmount(@PathVariable String custId, @PathVariable double amount) {
		System.out.println("AAA"); 
			Customer customer= capgService.findCustomerById(custId);
			System.out.println("AAA");
			customer.setWalletBalance(customer.getWalletBalance()+amount);
			System.out.println(customer.getWalletBalance());
			capgService.updateCustomer( customer);
		
	}
	@RequestMapping(value="/ecommerce/186133/checkBalance/{custId}")
	public double checkAmount(@PathVariable String custId) {
		//System.out.println("AAA"); 
			Customer customer= capgService.findCustomerById(custId);
			//System.out.println("AAA");
			return customer.getWalletBalance();
			//capgService.updateCustomer( customer);
		
	}
	
	@RequestMapping(value="ecommerce/186133/updateProfile/{custId}",method =RequestMethod.PUT)
	public void updateCustomerById(@PathVariable String custId, @RequestBody Customer customer) {
		Customer customer1 = capgService.findCustomerById(custId);
		customer.setEmailId(customer1.getEmailId());
		customer.setWalletBalance(customer1.getWalletBalance());
		capgService.updateCustomer( customer);
	}
	@RequestMapping(value="ecommerce/186133/getProfile/{custId}")
	public void getCustomerById(@PathVariable String custId) {
		capgService.findCustomerById(custId);
	}
	@RequestMapping(value="ecommerce/186133/viewOrderedItems/{custId}")
	public List<OrderedItem> getOrderedItemsByCustId(@PathVariable String custId){
		List<OrderedItem> items = capgService.getOrderedItemsByCustId();
		List<OrderedItem> custList = new ArrayList<>();
		for(int i=0;i<items.size();i++) {
			System.out.println(items.get(i));
			if(items.get(i).getCustomer().getCustId().equals(custId))
			{
		     custList.add(items.get(i));
		}
			}
	    return custList;
		
	}
	
	@RequestMapping("ecommerce/186133/getcustomerwishlist/{custid}")
	public List<WishItem> getCustomerWishById(@PathVariable String custid){
		return capgService.getWishListByCustomerId(custid);
	}

}

package com.capg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.bean.OrderedItem;

public interface CapgOrderedItem extends JpaRepository<OrderedItem, String>{

}

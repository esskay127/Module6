import { Product } from './product';
import { Merchant } from './merchant';
import { Customer } from './customer';
import { Coupon } from './coupon';
import { Transaction } from './transaction';
 
export class OrderedItem {
 ordId: string;
    customer: Customer;
    product: Product;
    merchant: Merchant; 
    orderTime: string;
    ordPrice: number;
    shippingAddress: string;
    ordStatus: string;
    couponCode: Coupon;
    ordTransaction: Transaction;
    ordQty: number;
}
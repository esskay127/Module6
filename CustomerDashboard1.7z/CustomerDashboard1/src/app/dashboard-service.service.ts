import { Injectable } from '@angular/core';
import {HttpClient } from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Customer } from './Customer';
import { OrderedItem } from './OrderedItem';

@Injectable({
  providedIn: 'root'
})
export class DashboardServiceService {
  id :string="CUST_00001"
  customer: Customer;
 
  constructor(private httpclient:HttpClient ) { }

  private _url: string = 'http://localhost:8081/ecommerce/186133/';


   public getOrderedItemsByCustId(custId: string): Observable<OrderedItem[]> {
     let orderedItemUrl = this._url+`viewOrderedItems/${custId}`;
     console.log(orderedItemUrl);
     return this.httpclient.get<OrderedItem[]>(orderedItemUrl)

   }
   public deposit(amount:string){
    return this.httpclient.put<Customer>(this._url+'deposit/'+this.id+'/'+amount,'')

   }
public checkBalance():Observable<number>{
return this.httpclient.get<number>(this._url+'checkBalance/'+this.id)


}
public setProfileAttributes(customer: Customer):Observable<Customer>{
  return this.httpclient.put<Customer>(this._url+'updateProfile/'+this.id,customer)
}

/*public getWishList():{
  this.httpclient.get("http://localhost:8081/ecommerce/186133/getcustomerwishlist/CUST_00003")
}*/

}

export class Transaction {
    transId: string;
    ordId: string;
    paymentMode: string;
   }
import { Component, OnInit } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { OrderedItem } from '../OrderedItem';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private dashboardService:  DashboardServiceService, private orderItemsRouter: Router) { }

  ngOnInit() {
  }

  getOrderedItems(custId: string){
console.log(custId);
      this.dashboardService.getOrderedItemsByCustId(custId).subscribe((orderedItems:OrderedItem[])=> {
        console.log(orderedItems);
        this.orderItemsRouter.navigate(['/orderedItems'])
      })
  }
 

}

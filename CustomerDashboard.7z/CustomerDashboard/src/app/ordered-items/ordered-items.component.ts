import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ordered-items',
  templateUrl: './ordered-items.component.html',
  styleUrls: ['./ordered-items.component.css']
})
export class OrderedItemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { OrderedItemsComponent } from './ordered-items/ordered-items.component';
import { WalletComponent } from './wallet/wallet.component';


const routes: Routes = [ {
 path: "updateProfile",
 component: UpdateProfileComponent 
} ,
{
  path: "dashboard",
  component: DashboardComponent
},
{
  path: "orderedItems",
  component: OrderedItemsComponent
},

{path: "wallet",
component: WalletComponent

},
{
  path: "**",
  redirectTo : "dashboard",
  pathMatch: "full"
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
